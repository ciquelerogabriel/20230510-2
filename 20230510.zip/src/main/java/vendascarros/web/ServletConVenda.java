package vendascarros.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vendascarros.Carro;
import vendascarros.persistencia.CadVendaBD;

@WebServlet("/convenda")
public class ServletConVenda extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public ServletConVenda() {
		super();

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//preparando o response
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		try {
			String sPlaca = request.getParameter("placa");
			if (sPlaca == null) {
				sPlaca = " ";
			}
			//objeto de consulta
			CadVendaBD bd = new CadVendaBD();
			//executar método de busca	
			ArrayList<Carro> lista = bd.consultarPorPlaca(sPlaca);
			//percorrer lista de retorno
			for (Carro c: lista) {
				pw.print("* " + c.getAnoCarro() + "|" + c.getPlacaCarro() + "<br>");	
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



}
