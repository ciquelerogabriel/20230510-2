package vendascarros.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UtilJDBC {
	static final String url =
			//jdbc:banco:ip_servidor:porta/database
			"jdbc:mysql://127.0.0.1:3306/vendacarros";
	static final String param = "?useTimezone=true&serverTimezone=UTC&characterEncoding=UTF-8&autoReconnect=true&useSSL=false";
	static final String usuario = "root";
	static final String senha = "aluno";

	public static Connection getConnection() throws Exception
	{
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("JDBC Driver Ok");
			con = DriverManager.getConnection(url+param,usuario,senha);
			if (con != null) {
				System.out.println("Conexão Ok");
				return con;
			} else {
				throw new Exception("A conexão não foi criada!"); }
		} catch (ClassNotFoundException e) {
			System.out.println("Driver JDBC inválido");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Falha na conexão");
			e.printStackTrace();
		}
		return con;
	} 
}
