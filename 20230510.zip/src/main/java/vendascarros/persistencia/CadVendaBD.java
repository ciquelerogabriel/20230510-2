package vendascarros.persistencia;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vendascarros.Carro;

public class CadVendaBD {


	public ArrayList<Carro> consultarPorPlaca (String strPlaca) throws Exception {
		ArrayList<Carro> carros = new ArrayList<Carro>();
		Carro cr = null;
		PreparedStatement stmt = null;
		Connection con = null;
		String sql ="SELECT id, idCliente, marca, modelo, ano, placa, chassi, valor,  garantia, data "
				+ " FROM vendacarro where placa like ?";
		try {
			con = UtilJDBC.getConnection();
			stmt = con.prepareStatement(sql);
			stmt.setString(1, "%"+ 	strPlaca + "%");
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				cr = new Carro();
				cr.setId(rs.getInt("id"));
				cr.setIdCliente(rs.getInt("idCliente"));
				cr.setMarcaCarro(rs.getString("marca"));
				cr.setModeloCarro(rs.getString("modelo"));
				cr.setAnoCarro(rs.getInt("ano"));
				cr.setPlacaCarro(rs.getString("placa"));
				cr.setChassiCarro(rs.getString("chassi"));
				cr.setValorCarro(Double.valueOf(rs.getString("valor")));
				cr.setGarantiaCarro(rs.getString("garantia"));
				cr.setDataCarro(rs.getString("data"));
				//adiciona objeto no arraylist
				carros.add(cr);
			} 
		} catch (Exception e ) {
			System.out.println(e);
		} finally {
			if (stmt != null) { stmt.close(); }
			if (con != null) { con.close();}
		}
		return carros;
	}




	public boolean inserir(Carro c) throws Exception {
		boolean retorno = false;
		//comentario
		PreparedStatement stmt = null;
		Connection con = null;
		String sql = "INSERT INTO vendacarro( marca, modelo, ano, placa, chassi, valor, data, garantia, idcliente)VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			con = UtilJDBC.getConnection();
			stmt = con.prepareStatement(sql);
			stmt.setString(1, c.getMarcaCarro());
			stmt.setString(2, c.getModeloCarro());
			stmt.setInt(3, c.getAnoCarro());
			stmt.setString(4, c.getPlacaCarro());
			stmt.setString(5, c.getChassiCarro());
			stmt.setString(6, String.valueOf(c.getValorCarro()));
			stmt.setDate(7, Date.valueOf(c.getDataCarro()));
			stmt.setString(8, c.getGarantiaCarro());
			stmt.setInt(9, 1);

			stmt.executeUpdate();
			retorno = true;
		} catch (Exception e ) {
			System.out.println(e);
		} finally {
			if (stmt != null) { 
				stmt.close(); 
			}
			if (con != null) { 
				con.close();
			}
		}
		return retorno; }
}
