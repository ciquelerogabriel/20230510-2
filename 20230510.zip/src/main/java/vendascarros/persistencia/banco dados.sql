

--TABELA COM INFORMAÇÕES DO CLIENTE
CREATE TABLE Cliente (
id integer not null AUTO_INCREMENT,
nome varchar(100) not null,
cpf varchar(14) not null,
contato varchar(21) not null,
PRIMARY KEY (id));



--TABELA COM INFORMAÇÕES DE VENDA
CREATE TABLE VendaCarro (
id INTEGER not null AUTO_INCREMENT,
idCliente integer not null,
marca varchar(100) not null,
modelo varchar(100) not null,
ano varchar(4) not null,
placa varchar(8) not null,
chassi varchar(17) not null,
valor varchar(25) not null,
data date not null,
garantia varchar(3) not null,
PRIMARY KEY (id));


ALTER TABLE VendaCarro ADD CONSTRAINT fk_cliente FOREIGN KEY (idCliente) REFERENCES Cliente (id);

INSERT INTO cliente (nome,cpf,contato)VALUES('Fulano','00011133322','fulano@mail.com');